Hello and thank you for grading my homework!


To compile this you may use the command 
gcc --std=gnu99 -o movies_by_year movies_by_year.c



